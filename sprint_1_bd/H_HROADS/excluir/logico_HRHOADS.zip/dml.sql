INSERT INTO HABILIDADE (idHabilidade, nomeHabilidade)
VALUES (1, 'Lança Mortal'), (2, 'Escudo Supremo'), (3, 'Recuperar Vida')
GO

INSERT INTO TIPO_HABILIDADE (idTipo, nomeTipo)
VALUES (1, 'Ataque'), (2, 'Defesa'), (3, 'Cura'), (4, 'Magia')
GO

INSERT INTO PERSONAGEM (idPersona, nomePersona)
VALUES (1, 'DeuBug'), (2, 'BitBug'), (3, 'Fer8')
GO